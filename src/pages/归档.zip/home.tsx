import { useState } from 'react';
import { Call1Icon, CloseCircleIcon } from 'tdesign-icons-react';
import { Button } from 'tdesign-react';

import './home.less';

function Home() {
  const [inputValue, setInputValue] = useState<string[]>([]);
  const keys = [
    [[1], [2, 'a', 'b', 'c'], [3, 'd', 'e', 'f']],
    [
      [4, 'g', 'h', 'i'],
      [5, 'j', 'k', 'l'],
      [6, 'm', 'n', 'o'],
    ],
    [
      [7, 'p', 'q', 'r', 's'],
      [8, 't', 'u', 'v'],
      [9, 'w', 'x', 'y', 'z'],
    ],
    [['*'], [0, '+'], ['#']],
  ];

  const handleKeyClick = (value: string) => {
    setInputValue((prev) => [...prev, value]);
  };
  const handleClose = () => {
    setInputValue((prev) => {
      const newValue = [...prev];
      newValue.pop();
      return newValue;
    });
  };
  const hasInput = inputValue?.length > 0;
  return (
    <div className="home-page-wappr">
      <div className="display-wapper"> {inputValue}</div>
      <div className="keybroad-wapper">
        {keys.map((row) => {
          return (
            <div className="key-list">
              {row.map((item) => {
                const [number, ...rest] = item;
                return (
                  <div className="key-item" onClick={() => handleKeyClick(number as unknown as string)}>
                    <span>{number}</span>
                    <span>{rest.join('')}</span>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
      <div className="confrom-actions">
        <Button shape="circle" className="btn-call" icon={<Call1Icon />} />
        {hasInput && <Button className="btn-delete" icon={<CloseCircleIcon />} onClick={handleClose} />}
      </div>
    </div>
  );
}

export default Home;
