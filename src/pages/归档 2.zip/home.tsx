import { useState } from 'react';
import { Call1Icon, CloseCircleIcon } from 'tdesign-icons-react';
import { Button } from 'tdesign-react';

import { KeyBroad } from './components';
import './home.less';

function Home() {
  const [inputValue, setInputValue] = useState<string[]>([]);

  const handleKeyClick = (value: string) => {
    setInputValue((prev) => [...prev, value]);
  };
  const handleClose = () => {
    setInputValue((prev) => {
      // return prev.filter((_, index) => index !== prev.length - 1);
      const newValue = [...prev];
      newValue.pop();
      return newValue;
    });
  };
  const hasInput = inputValue?.length > 0;
  return (
    <div className="home-page-wappr">
      <div className="display-wapper"> {inputValue.join('')}</div>
      <KeyBroad onChange={handleKeyClick} />
      <div className="confrom-actions">
        <Button shape="circle" className="btn-call" icon={<Call1Icon />} />
        {hasInput && <Button className="btn-delete" icon={<CloseCircleIcon />} onClick={handleClose} />}
      </div>
    </div>
  );
}

export default Home;
